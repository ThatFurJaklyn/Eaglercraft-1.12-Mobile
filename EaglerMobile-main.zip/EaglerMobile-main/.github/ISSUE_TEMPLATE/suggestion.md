---
name: Suggestion
about: Suggest an idea for this project
title: "[Suggestion]"
labels: suggestion
assignees: ''

---

**Suggestion**
Provide a clear and concise description of the suggestion.

**Additional Information**
Provide a clear and concise explanation for what changes would need to take place in order for the suggestion to be possible.
